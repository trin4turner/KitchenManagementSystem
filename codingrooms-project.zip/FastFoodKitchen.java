import java.util.*;
import java.util.ArrayList;
import java.io.File;
import java.io.*;
import java.util.Scanner;

/**
 *
 * ITSC 1213 
 * University of North Carolina at Charlotte
 */

public class FastFoodKitchen {

    private ArrayList<BurgerOrder> orderList = new ArrayList();     
    private ArrayList<BurgerOrder> completedOrders = new ArrayList(); 
    private ArrayList <BurgerOrder> updatedOrder = new ArrayList();     


    String line;
    private static int nextOrderNum = 1;
    int lineCount = 1;
    FastFoodKitchen() {
        orderList.add(new BurgerOrder(5, 15, 4, 10, false, getNextOrderNum()));
        incrementNextOrderNum();
        orderList.add(new BurgerOrder(4, 10, 3, 3, true, getNextOrderNum()));
        incrementNextOrderNum();
        orderList.add(new BurgerOrder(6, 1, 1, 2, false, getNextOrderNum()));
        incrementNextOrderNum();
        //might need try to catch
        try{
            //code to add file orders to list
         Scanner fileScanner  = new Scanner(new File("burgerOrders-1 (1).csv"));
        while(fileScanner.hasNext()){
            
            line = fileScanner.nextLine();
            String[]data = line.split(",");
            
            fileScanner.forEachRemaining(line -> {
            if(Integer.parseInt(data[0]) >= 1){
                BurgerOrder fileOrders = new BurgerOrder(Integer.parseInt(data[0]),Integer.parseInt(data[1]),Integer.parseInt(data[2]),Integer.parseInt(data[3]),Boolean.parseBoolean(data[4]),Integer.parseInt(data[5], getNextOrderNum()));
                orderList.add(fileOrders);
            }//end of if 
        
        }); //ends each remaining loop
    }//ends while loop
            fileScanner.close();

}//ends try
catch(FileNotFoundException ex){
    System.out.println("Sorry we could not find that file");
}


    }//ends constructor
    
// //alter method to also check completed arraylist so that we can update our end of day report
//     public boolean isOrderDone(int orderID) {
//         for (int i = 0; i < orderList.size(); i++) {
//             if (orderList.get(i).getOrderNum() == orderID) {
//                 return false;
//             } else {
//                 for(i = 0; i < completedOrders.size(); i++){
//                     if(completedOrders.get(i).getOrderNum()==orderID){
//                         return true;
//                     }
//                   }
//              }

//          }
//     }  

    //Creates a new file that puts in the final order list

    public void updatedOrdersList(){
        try{
        FileOutputStream fo = new FileOutputStream("UpdatedOrders.csv");
        PrintWriter outFO = new PrintWriter(fo);
        //because orderList is updated when orders are completed or canceeled, this will only retriece the pending orders
        for(BurgerOrder o : orderList){
            outFO.println(o.getNumHamburger()+ "," +o.getNumCheeseburgers()+ ","+o.getNumVeggieburgers()+","+o.getNumSodas()+","+o.isOrderToGo()+"," + o.getOrderNum());

        }
        outFO.close();
        fo.close();
        }//end updated orders try
        
        catch(IOException e){
            System.out.println("error found! try again");
        }
        
    }//end updated orders method

    //method to print out exactly what was ordered and totals of each
    public void printEndOfDayReport(){
    try{
     FileOutputStream fs = new FileOutputStream("EndOfDayReport");
     PrintWriter outFS = new PrintWriter(fs);
      outFS.println("End of day report: ");
      //create varibles of totals of each item and assign them to 0
      
        int sumHam = 0;
        int sumCheese = 0;
        int sumVeg = 0;
        int sumSodas = 0;
        //create loop tthat displays each order, and adds the number of each item to the count, and whether it was completed
      for(BurgerOrder o :orderList){
          outFS.println(o.toString());
          outFS.println(" ");
          sumHam += o.getNumHamburger();
          sumCheese +=o.getNumCheeseburgers();
          sumVeg += o.getNumVeggieburgers();
          sumSodas += o.getNumSodas();
          outFS.println("======================================");
          //if statement to check if orderNumber has been completed
          if(this.isOrderDone(o.getOrderNum()) == true){
              outFS.println("Order number "+ o.getOrderNum()+ " was completed");
          }
          else{
              outFS.println("Order number "+o.getOrderNum()  + " was not completed");
          }

      }//end of for each
      //displays all totals
    outFS.println("Total Hamburgers of the day: "+ sumHam);
    outFS.println("Total CheeseBurgers of the day: "+ sumCheese);
    outFS.println("Total VeggieBurgers of the day: "+ sumVeg);
    outFS.println("Total Sodas of the day: "+ sumSodas);


    outFS.close();
    fs.close();
    }//end of try
    catch(IOException e){
        System.out.println("Cannot create Report, try afgain");
    }//end of report catch
}//end of endofday method


    public static int getNextOrderNum() {
        return nextOrderNum;
    }

    private void incrementNextOrderNum() {
        nextOrderNum++;
    }
    
    public int addOrder(int ham, int cheese, int veggie, int soda, boolean toGo) {
        int orderNum = getNextOrderNum();
        orderList.add(new BurgerOrder(ham, cheese, veggie, soda, toGo, orderNum));
        incrementNextOrderNum();
        orderCallOut(orderList.get(orderList.size() - 1));
        return orderNum;

    }
    
    public boolean cancelOrder(int orderID) {
        for (int i = 0; i < orderList.size(); i++) {
            if (orderList.get(i).getOrderNum() == orderID) {
                orderList.remove(i);
                return true;
            }
        }
        return false;
    }

    public int getNumOrdersPending() {

        return orderList.size();
    }

//alter method to also check completed arraylist so that we can update our end of day report
    public boolean isOrderDone(int orderID) {
        for (int i = 0; i < orderList.size(); i++) {
            if (orderList.get(i).getOrderNum() == orderID) {
                return false;
            }      
         }
         //add loop to see if the order is in the completed orders
         for(int i = 0; i < completedOrders.size(); i++){
                    if(completedOrders.get(i).getOrderNum()==orderID){
                        return true;
                    }
                  }
                  return false;
    }

    public boolean cancelLastOrder() {

        if (!orderList.isEmpty()) { // same as  if (orderList.size() > 0) 
            orderList.remove(orderList.size() - 1);
            return true;
        }

        return false;
    }

    private void orderCallOut(BurgerOrder order) {
        if (order.getNumCheeseburgers() > 0) {
            System.out.println("You have " + order.getNumHamburger() + " hamburgers");
        }
        if (order.getNumCheeseburgers() > 0) {
            System.out.println("You have " + order.getNumCheeseburgers() + " cheeseburgers");
        }
        if (order.getNumVeggieburgers() > 0) {
            System.out.println("You have " + order.getNumVeggieburgers() + " veggieburgers");
        }
        if (order.getNumSodas() > 0) {
            System.out.println("You have " + order.getNumSodas() + " sodas");
        }

    }

    public void completeSpecificOrder(int orderID) {
        for (int i = 0; i < orderList.size(); i++) {
            if (orderList.get(i).getOrderNum() == orderID) {
                System.out.println("Order number " + orderID + " is done!");
                if (orderList.get(i).isOrderToGo()) {
                    orderCallOut(orderList.get(i));
                }
                //add to  completed orders arrayList when ordeer is considered comolete
                 completedOrders.add(orderList.get(i));
                 orderList.remove(i);
            }
        }

    }

    public void completeNextOrder() {
        int nextOrder = orderList.get(0).getOrderNum();
        completeSpecificOrder(nextOrder);

    }

    // Part 2
    public ArrayList<BurgerOrder> getOrderList() {
        return orderList;
    }

    public int findOrderSeq(int whatWeAreLookingFor) {
        for (int j = 0; j < orderList.size(); j++) {
            if (orderList.get(j).getOrderNum() == whatWeAreLookingFor) {
                return j;
            }
        }
        return -1;
    }

//    public int findOrderBin(int whatWeAreLookingFor) {
//        int left = 0;
//        int right = orderList.size() - 1;
//        while (left <= right) {
//            int middle = (left + right) / 2;
//            if (whatWeAreLookingFor < orderList.get(middle).getOrderNum()) {
//                right = middle - 1;
//            } else if (whatWeAreLookingFor > orderList.get(middle).getOrderNum()) {
//                left = middle + 1;
//            } else {
//                return middle;
//            }
//        }
//        return -1;
//    }

  public int findOrderBin(int orderID){
        int left = 0;
        int right = orderList.size()-1;
        while (left <= right){
            int middle = ((left + right)/2);
            if (orderID < orderList.get(middle).getOrderNum()){
                right = middle-1;
            }
            else if(orderID > orderList.get(middle).getOrderNum()){
                left = middle +1;
            }
            else{
                return middle;
            }
        }
        return -1;
        
    }
    public void selectionSort(){
        for (int i = 0; i< orderList.size()-1; i++){
            int minIndex = i;
            for (int k = i+1; k < orderList.size(); k++){
                if (orderList.get(minIndex).getTotalBurgers() > orderList.get(k).getTotalBurgers()){
                    minIndex = k;
                }
            }
            BurgerOrder temp = orderList.get(i);
            orderList.set(i , orderList.get(minIndex));
            orderList.set(minIndex, temp);
        }
    }

    public void insertionSort() {
        for (int j = 1; j < orderList.size(); j++) {
            BurgerOrder temp = orderList.get(j);
            int possibleIndex = j;
            while (possibleIndex > 0 && temp.getTotalBurgers() < orderList.get(possibleIndex - 1).getTotalBurgers()) {
                orderList.set(possibleIndex, orderList.get(possibleIndex - 1));
                possibleIndex--;
            }
            orderList.set(possibleIndex, temp);
        }
    }
    
//    public void selectionSort() { //weird method!
//
//        for (int j = 0; j < orderList.size() - 1; j++) {
//            int minIndex = j;
//            for (int k = j + 1; k < orderList.size(); k++) {
//
//                 if (orderList.get(minIndex).getTotalBurgers() > orderList.get(j).getTotalBurgers()){
//                    minIndex = k;
//                }
//            }
//            BurgerOrder temp = orderList.get(j);
//            orderList.set(j, orderList.get(minIndex));
//            orderList.set(minIndex, temp);
//
//        }
//    }

}
